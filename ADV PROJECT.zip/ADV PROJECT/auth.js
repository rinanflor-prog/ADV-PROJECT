(() => {
	const accountsStorageKey = "document-request-tracker.demo-accounts.v1";
	const passwordHashIterations = 210000;
	const studentIdInput = document.querySelector("#student-id");

	studentIdInput.addEventListener("input", () => {
		studentIdInput.value = studentIdInput.value.replace(/[^0-9]/g, "").slice(0, 8);
	});

	function isValidStudentId(studentId) {
		return /^[0-9]{8}$/.test(studentId);
	}

	function normalizeStudentId(studentId) {
		return studentId.trim().toLowerCase();
	}

	function readAccounts() {
		const savedAccounts = localStorage.getItem(accountsStorageKey);
		if (!savedAccounts) return [];

		const accounts = JSON.parse(savedAccounts);
		if (!Array.isArray(accounts)) throw new Error("Saved demo account data is invalid.");
		return accounts;
	}

	function bytesToHex(bytes) {
		return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
	}

	function hexToBytes(hex) {
		if (!/^(?:[0-9a-f]{2})+$/i.test(hex)) throw new Error("Saved demo account data is invalid.");
		const bytes = new Uint8Array(hex.length / 2);
		for (let index = 0; index < bytes.length; index += 1) {
			bytes[index] = Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16);
		}
		return bytes;
	}

	async function hashPassword(password, salt, iterations) {
		if (!window.crypto?.subtle) {
			throw new Error("Open this demo using its localhost address to enable account sign-in.");
		}

		const keyMaterial = await window.crypto.subtle.importKey(
			"raw",
			new TextEncoder().encode(password),
			"PBKDF2",
			false,
			["deriveBits"]
		);
		const derivedBits = await window.crypto.subtle.deriveBits(
			{ name: "PBKDF2", salt, iterations, hash: "SHA-256" },
			keyMaterial,
			256
		);
		return bytesToHex(new Uint8Array(derivedBits));
	}

	function hashesMatch(expectedHash, actualHash) {
		if (expectedHash.length !== actualHash.length) return false;
		let difference = 0;
		for (let index = 0; index < expectedHash.length; index += 1) {
			difference |= expectedHash.charCodeAt(index) ^ actualHash.charCodeAt(index);
		}
		return difference === 0;
	}

	async function createAccount({ fullName, studentId, password }) {
		const accounts = readAccounts();
		if (!isValidStudentId(studentId)) {
			throw new Error("Student ID must contain exactly 8 numbers.");
		}
		const normalizedStudentId = normalizeStudentId(studentId);
		if (accounts.some((account) => account.normalizedStudentId === normalizedStudentId)) {
			throw new Error("An account with this Student ID already exists.");
		}

		const salt = window.crypto.getRandomValues(new Uint8Array(16));
		const passwordHash = await hashPassword(password, salt, passwordHashIterations);
		const account = {
			fullName: fullName.trim(),
			studentId: studentId.trim(),
			normalizedStudentId,
			salt: bytesToHex(salt),
			passwordHash,
			iterations: passwordHashIterations
		};
		accounts.push(account);
		localStorage.setItem(accountsStorageKey, JSON.stringify(accounts));
		return { fullName: account.fullName, studentId: account.studentId };
	}

	async function signIn(studentId, password) {
		if (!isValidStudentId(studentId)) return null;
		const normalizedStudentId = normalizeStudentId(studentId);
		const accounts = readAccounts();
		if (accounts.length === 0) {
			throw new Error("No student account has been created yet. Please create an account first.");
		}
		const account = accounts.find((savedAccount) => savedAccount.normalizedStudentId === normalizedStudentId);
		if (!account) return null;

		const passwordHash = await hashPassword(password, hexToBytes(account.salt), account.iterations);
		if (!hashesMatch(account.passwordHash, passwordHash)) return null;
		return { fullName: account.fullName, studentId: account.studentId };
	}

	function getAccount(studentId) {
		const normalizedStudentId = normalizeStudentId(studentId);
		const account = readAccounts().find((savedAccount) => savedAccount.normalizedStudentId === normalizedStudentId);
		return account ? { fullName: account.fullName, studentId: account.studentId } : null;
	}

	window.demoAuth = Object.freeze({ createAccount, signIn, getAccount });
})();